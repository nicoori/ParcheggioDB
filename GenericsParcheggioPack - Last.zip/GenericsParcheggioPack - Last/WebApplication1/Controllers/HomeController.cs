﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    [Route("api/v1")]
    [ApiController]
    public class LoginController : ControllerBase
    {
        [HttpPost("login")]
        public ActionResult Login([FromBody] TblUser tblUser)
        {
            using (ParcheggioDBContext model = new ParcheggioDBContext())
            {
                TblUser candidate = model.TblUsers.FirstOrDefault(q => q.UserName == tblUser.UserName && q.Password == tblUser.Password);

                if (candidate == null) return Ok("Username o password errati");

                var tokenHandler = new JwtSecurityTokenHandler();
                var tokenDescriptor = new SecurityTokenDescriptor
                {
                    SigningCredentials = new SigningCredentials(SecurityKeyGenerator.GetSecurityKey(candidate), SecurityAlgorithms.HmacSha256Signature),
                    Expires = DateTime.UtcNow.AddDays(1),
                    Subject = new ClaimsIdentity(
                        new Claim[]
                        {
                            new Claim("id",candidate.Iduser.ToString())
                        }
                    )
                };

                SecurityToken token = tokenHandler.CreateToken(tokenDescriptor);
                return Ok(tokenHandler.WriteToken(token));
            }
        }

        [Authorize]
        [HttpPost("logout")]
        public ActionResult Logout()
        {
            using (ParcheggioDBContext model = new ParcheggioDBContext())
            {
                int idUtente = Int32.Parse(HttpContext.User.Claims.FirstOrDefault(x => x.Type == "id").Value);
                TblUser candidate = model.TblUsers.FirstOrDefault(q => q.Iduser == idUtente);
                if (candidate == null) return NotFound();

                return Ok();
            }
        }
    }
}
