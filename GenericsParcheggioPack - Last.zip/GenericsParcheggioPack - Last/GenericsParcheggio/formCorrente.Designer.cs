﻿
namespace GenericsParcheggio
{
    partial class formCorrente
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(formCorrente));
            this.bindingCorrente = new System.Windows.Forms.BindingSource(this.components);
            this.parcheggioDBDataSet7 = new GenericsParcheggio.ParcheggioDBDataSet7();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.targaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tipoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nomeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cognomeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataIngressoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.prezzoInizialeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.posXDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.posYDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.viewCorrenteFinaleBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.viewCorrenteFinaleTableAdapter = new GenericsParcheggio.ParcheggioDBDataSet7TableAdapters.ViewCorrenteFinaleTableAdapter();
            this.lbTitolo = new System.Windows.Forms.Label();
            this.btnIndietro = new GenericsParcheggio.RJButton();
            this.Cerca = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.bindingCorrente)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.parcheggioDBDataSet7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewCorrenteFinaleBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // bindingCorrente
            // 
            this.bindingCorrente.DataSource = this.parcheggioDBDataSet7;
            this.bindingCorrente.Position = 0;
            // 
            // parcheggioDBDataSet7
            // 
            this.parcheggioDBDataSet7.DataSetName = "ParcheggioDBDataSet7";
            this.parcheggioDBDataSet7.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // dataGridView1
            // 
            this.dataGridView1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.AliceBlue;
            this.dataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridView1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.targaDataGridViewTextBoxColumn,
            this.tipoDataGridViewTextBoxColumn,
            this.nomeDataGridViewTextBoxColumn,
            this.cognomeDataGridViewTextBoxColumn,
            this.dataIngressoDataGridViewTextBoxColumn,
            this.prezzoInizialeDataGridViewTextBoxColumn,
            this.posXDataGridViewTextBoxColumn,
            this.posYDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.viewCorrenteFinaleBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(12, 84);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersVisible = false;
            this.dataGridView1.RowHeadersWidth = 51;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.AliceBlue;
            this.dataGridView1.RowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(1002, 469);
            this.dataGridView1.TabIndex = 0;
            // 
            // targaDataGridViewTextBoxColumn
            // 
            this.targaDataGridViewTextBoxColumn.DataPropertyName = "Targa";
            this.targaDataGridViewTextBoxColumn.HeaderText = "Targa";
            this.targaDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.targaDataGridViewTextBoxColumn.Name = "targaDataGridViewTextBoxColumn";
            this.targaDataGridViewTextBoxColumn.Width = 125;
            // 
            // tipoDataGridViewTextBoxColumn
            // 
            this.tipoDataGridViewTextBoxColumn.DataPropertyName = "Tipo";
            this.tipoDataGridViewTextBoxColumn.HeaderText = "Tipo";
            this.tipoDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.tipoDataGridViewTextBoxColumn.Name = "tipoDataGridViewTextBoxColumn";
            this.tipoDataGridViewTextBoxColumn.Width = 125;
            // 
            // nomeDataGridViewTextBoxColumn
            // 
            this.nomeDataGridViewTextBoxColumn.DataPropertyName = "Nome";
            this.nomeDataGridViewTextBoxColumn.HeaderText = "Nome";
            this.nomeDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.nomeDataGridViewTextBoxColumn.Name = "nomeDataGridViewTextBoxColumn";
            this.nomeDataGridViewTextBoxColumn.Width = 125;
            // 
            // cognomeDataGridViewTextBoxColumn
            // 
            this.cognomeDataGridViewTextBoxColumn.DataPropertyName = "Cognome";
            this.cognomeDataGridViewTextBoxColumn.HeaderText = "Cognome";
            this.cognomeDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.cognomeDataGridViewTextBoxColumn.Name = "cognomeDataGridViewTextBoxColumn";
            this.cognomeDataGridViewTextBoxColumn.Width = 125;
            // 
            // dataIngressoDataGridViewTextBoxColumn
            // 
            this.dataIngressoDataGridViewTextBoxColumn.DataPropertyName = "DataIngresso";
            this.dataIngressoDataGridViewTextBoxColumn.HeaderText = "DataIngresso";
            this.dataIngressoDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.dataIngressoDataGridViewTextBoxColumn.Name = "dataIngressoDataGridViewTextBoxColumn";
            this.dataIngressoDataGridViewTextBoxColumn.Width = 125;
            // 
            // prezzoInizialeDataGridViewTextBoxColumn
            // 
            this.prezzoInizialeDataGridViewTextBoxColumn.DataPropertyName = "PrezzoIniziale";
            this.prezzoInizialeDataGridViewTextBoxColumn.HeaderText = "PrezzoIniziale";
            this.prezzoInizialeDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.prezzoInizialeDataGridViewTextBoxColumn.Name = "prezzoInizialeDataGridViewTextBoxColumn";
            this.prezzoInizialeDataGridViewTextBoxColumn.Width = 125;
            // 
            // posXDataGridViewTextBoxColumn
            // 
            this.posXDataGridViewTextBoxColumn.DataPropertyName = "PosX";
            this.posXDataGridViewTextBoxColumn.HeaderText = "PosX";
            this.posXDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.posXDataGridViewTextBoxColumn.Name = "posXDataGridViewTextBoxColumn";
            this.posXDataGridViewTextBoxColumn.Width = 125;
            // 
            // posYDataGridViewTextBoxColumn
            // 
            this.posYDataGridViewTextBoxColumn.DataPropertyName = "PosY";
            this.posYDataGridViewTextBoxColumn.HeaderText = "PosY";
            this.posYDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.posYDataGridViewTextBoxColumn.Name = "posYDataGridViewTextBoxColumn";
            this.posYDataGridViewTextBoxColumn.Width = 125;
            // 
            // viewCorrenteFinaleBindingSource
            // 
            this.viewCorrenteFinaleBindingSource.DataMember = "ViewCorrenteFinale";
            this.viewCorrenteFinaleBindingSource.DataSource = this.bindingCorrente;
            // 
            // viewCorrenteFinaleTableAdapter
            // 
            this.viewCorrenteFinaleTableAdapter.ClearBeforeFill = true;
            // 
            // lbTitolo
            // 
            this.lbTitolo.BackColor = System.Drawing.Color.SkyBlue;
            this.lbTitolo.Dock = System.Windows.Forms.DockStyle.Top;
            this.lbTitolo.Font = new System.Drawing.Font("Copperplate Gothic Bold", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTitolo.Location = new System.Drawing.Point(0, 0);
            this.lbTitolo.Name = "lbTitolo";
            this.lbTitolo.Size = new System.Drawing.Size(1029, 37);
            this.lbTitolo.TabIndex = 2;
            this.lbTitolo.Text = "Parcheggio Corrente";
            this.lbTitolo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnIndietro
            // 
            this.btnIndietro.BackColor = System.Drawing.Color.MediumSlateBlue;
            this.btnIndietro.BackgroundColor = System.Drawing.Color.MediumSlateBlue;
            this.btnIndietro.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.btnIndietro.BorderRadius = 10;
            this.btnIndietro.BorderSize = 0;
            this.btnIndietro.FlatAppearance.BorderSize = 0;
            this.btnIndietro.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnIndietro.Font = new System.Drawing.Font("Copperplate Gothic Bold", 7F);
            this.btnIndietro.ForeColor = System.Drawing.Color.White;
            this.btnIndietro.Location = new System.Drawing.Point(860, 559);
            this.btnIndietro.Name = "btnIndietro";
            this.btnIndietro.Size = new System.Drawing.Size(150, 27);
            this.btnIndietro.TabIndex = 3;
            this.btnIndietro.Text = "Indietro";
            this.btnIndietro.TextColor = System.Drawing.Color.White;
            this.btnIndietro.UseVisualStyleBackColor = false;
            this.btnIndietro.Click += new System.EventHandler(this.btnIndietro_Click_1);
            // 
            // Cerca
            // 
            this.Cerca.AutoSize = true;
            this.Cerca.Font = new System.Drawing.Font("Copperplate Gothic Bold", 8F);
            this.Cerca.Location = new System.Drawing.Point(9, 50);
            this.Cerca.Name = "Cerca";
            this.Cerca.Size = new System.Drawing.Size(58, 15);
            this.Cerca.TabIndex = 4;
            this.Cerca.Text = "Cerca";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(73, 46);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(937, 22);
            this.textBox1.TabIndex = 5;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // formCorrente
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SkyBlue;
            this.ClientSize = new System.Drawing.Size(1029, 598);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.Cerca);
            this.Controls.Add(this.btnIndietro);
            this.Controls.Add(this.lbTitolo);
            this.Controls.Add(this.dataGridView1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "formCorrente";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "formCorrente";
            this.Load += new System.EventHandler(this.formCorrente_Load);
            ((System.ComponentModel.ISupportInitialize)(this.bindingCorrente)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.parcheggioDBDataSet7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewCorrenteFinaleBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.BindingSource bindingCorrente;
        private ParcheggioDBDataSet7 parcheggioDBDataSet7;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.BindingSource viewCorrenteFinaleBindingSource;
        private ParcheggioDBDataSet7TableAdapters.ViewCorrenteFinaleTableAdapter viewCorrenteFinaleTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn targaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tipoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nomeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cognomeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataIngressoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn prezzoInizialeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn posXDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn posYDataGridViewTextBoxColumn;
        private System.Windows.Forms.Label lbTitolo;
        private RJButton btnIndietro;
        private System.Windows.Forms.Label Cerca;
        private System.Windows.Forms.TextBox textBox1;
    }
}