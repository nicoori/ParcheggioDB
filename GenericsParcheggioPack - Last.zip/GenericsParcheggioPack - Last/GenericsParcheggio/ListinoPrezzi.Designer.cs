﻿
namespace GenericsParcheggio
{
    partial class ListinoPrezzi
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ListinoPrezzi));
            this.lbTitolo = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lbTitolo
            // 
            this.lbTitolo.Dock = System.Windows.Forms.DockStyle.Top;
            this.lbTitolo.Font = new System.Drawing.Font("Copperplate Gothic Bold", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTitolo.Location = new System.Drawing.Point(0, 0);
            this.lbTitolo.Name = "lbTitolo";
            this.lbTitolo.Size = new System.Drawing.Size(800, 44);
            this.lbTitolo.TabIndex = 9;
            this.lbTitolo.Text = "Listino Prezzi";
            this.lbTitolo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label1.Font = new System.Drawing.Font("Copperplate Gothic Light", 8F, System.Drawing.FontStyle.Bold);
            this.label1.Location = new System.Drawing.Point(73, 63);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(232, 107);
            this.label1.TabIndex = 10;
            this.label1.Text = "TARIFFE ORARIE:\r\n- Utilitaria: 7,50€/h\r\n- Berlina: 8,00€/h\r\n- Auto Sportiva: 10,0" +
    "0€/h\r\n- SUV: 10,50€/h\r\n- Pick-Up: 11,00€/h\r\n- Camion: 11,50€/h\r\n";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label2.Font = new System.Drawing.Font("Copperplate Gothic Light", 8F, System.Drawing.FontStyle.Bold);
            this.label2.Location = new System.Drawing.Point(486, 78);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(216, 77);
            this.label2.TabIndex = 11;
            this.label2.Text = "TARIFFE SERVIZI:\r\n- Coperto: 5,00€\r\n- Pulizia interna: 7,00€\r\n- Pulizia esterna: " +
    "6,00€\r\n- Parcheggiatore: 3,00€";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ListinoPrezzi
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SkyBlue;
            this.ClientSize = new System.Drawing.Size(800, 241);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lbTitolo);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "ListinoPrezzi";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ListinoPrezzi";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbTitolo;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
    }
}