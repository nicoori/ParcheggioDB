﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GenericsParcheggio
{
    public partial class formCorrente : Form
    {
        public formCorrente()
        {
            InitializeComponent();
        }

        private void formCorrente_Load(object sender, EventArgs e)
        {
            // TODO: questa riga di codice carica i dati nella tabella 'parcheggioDBDataSet7.ViewCorrenteFinale'. È possibile spostarla o rimuoverla se necessario.
            this.viewCorrenteFinaleTableAdapter.Fill(this.parcheggioDBDataSet7.ViewCorrenteFinale);

        }

        private void btnIndietro_Click_1(object sender, EventArgs e)
        {
            this.Close();
            Form1 form1 = new Form1();
            form1.Show();

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            string connstring = "Server=DESKTOP-C85IVGL\\SQLEXPRESSNEW;Database=ParcheggioDB;User Id=sa;Password=Ciao*2002";
            using (SqlConnection connection = new SqlConnection(connstring))
            {
                connection.Open();
                SqlDataAdapter adapt;
                DataTable dt;
                string sqlinsert = "SELECT dbo.tblVeicolo.Targa, dbo.tblVeicolo.Tipo, dbo.tblPersona.Nome, dbo.tblPersona.Cognome, dbo.tblParcheggioCorrente.DataIngresso, dbo.tblParcheggioCorrente.PrezzoIniziale, dbo.tblParcheggioCorrente.PosX, dbo.tblParcheggioCorrente.PosY FROM     dbo.tblParcheggioCorrente INNER JOIN dbo.tblVeicolo ON dbo.tblParcheggioCorrente.IDVeicolo = dbo.tblVeicolo.IDVeicolo INNER JOIN dbo.tblPersona ON dbo.tblVeicolo.IDPersona = dbo.tblPersona.IDPersona" ;
                adapt = new SqlDataAdapter(sqlinsert, connection);
                dt = new DataTable();
                adapt.Fill(dt);

                sqlinsert = "SELECT dbo.tblVeicolo.Targa, dbo.tblVeicolo.Tipo, dbo.tblPersona.Nome, dbo.tblPersona.Cognome, dbo.tblParcheggioCorrente.DataIngresso, dbo.tblParcheggioCorrente.PrezzoIniziale, dbo.tblParcheggioCorrente.PosX, dbo.tblParcheggioCorrente.PosY FROM     dbo.tblParcheggioCorrente INNER JOIN dbo.tblVeicolo ON dbo.tblParcheggioCorrente.IDVeicolo = dbo.tblVeicolo.IDVeicolo INNER JOIN dbo.tblPersona ON dbo.tblVeicolo.IDPersona = dbo.tblPersona.IDPersona where Targa like '" + textBox1.Text + "%'";

                adapt = new SqlDataAdapter(sqlinsert, connection);
                dt = new DataTable();
                adapt.Fill(dt);
                dataGridView1.DataSource = dt;

            }
        }
    }
}
