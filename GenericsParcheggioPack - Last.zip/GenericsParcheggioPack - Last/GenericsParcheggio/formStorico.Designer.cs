﻿
namespace GenericsParcheggio
{
    partial class formStorico
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(formStorico));
            this.bindingStorico = new System.Windows.Forms.BindingSource(this.components);
            this.parcheggioDBDataSet7 = new GenericsParcheggio.ParcheggioDBDataSet7();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.targaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tipoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nomeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cognomeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataIngressoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataUscitaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.prezzoFinaleDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.posXDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.posYDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.viewStoricoBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.viewStoricoTableAdapter = new GenericsParcheggio.ParcheggioDBDataSet7TableAdapters.ViewStoricoTableAdapter();
            this.lbTitolo = new System.Windows.Forms.Label();
            this.dateTimeCalc2 = new System.Windows.Forms.DateTimePicker();
            this.dateTimeCalc1 = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.dataSingola = new System.Windows.Forms.RadioButton();
            this.dataDoppia = new System.Windows.Forms.RadioButton();
            this.btnIndietro = new GenericsParcheggio.RJButton();
            this.calcola = new GenericsParcheggio.RJButton();
            ((System.ComponentModel.ISupportInitialize)(this.bindingStorico)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.parcheggioDBDataSet7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewStoricoBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // bindingStorico
            // 
            this.bindingStorico.DataSource = this.parcheggioDBDataSet7;
            this.bindingStorico.Position = 0;
            // 
            // parcheggioDBDataSet7
            // 
            this.parcheggioDBDataSet7.DataSetName = "ParcheggioDBDataSet7";
            this.parcheggioDBDataSet7.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // dataGridView1
            // 
            this.dataGridView1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.AliceBlue;
            this.dataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridView1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.targaDataGridViewTextBoxColumn,
            this.tipoDataGridViewTextBoxColumn,
            this.nomeDataGridViewTextBoxColumn,
            this.cognomeDataGridViewTextBoxColumn,
            this.dataIngressoDataGridViewTextBoxColumn,
            this.dataUscitaDataGridViewTextBoxColumn,
            this.prezzoFinaleDataGridViewTextBoxColumn,
            this.posXDataGridViewTextBoxColumn,
            this.posYDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.viewStoricoBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(7, 40);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersVisible = false;
            this.dataGridView1.RowHeadersWidth = 51;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.AliceBlue;
            this.dataGridView1.RowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(1116, 466);
            this.dataGridView1.TabIndex = 0;
            // 
            // targaDataGridViewTextBoxColumn
            // 
            this.targaDataGridViewTextBoxColumn.DataPropertyName = "Targa";
            this.targaDataGridViewTextBoxColumn.HeaderText = "Targa";
            this.targaDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.targaDataGridViewTextBoxColumn.Name = "targaDataGridViewTextBoxColumn";
            this.targaDataGridViewTextBoxColumn.ReadOnly = true;
            this.targaDataGridViewTextBoxColumn.Width = 125;
            // 
            // tipoDataGridViewTextBoxColumn
            // 
            this.tipoDataGridViewTextBoxColumn.DataPropertyName = "Tipo";
            this.tipoDataGridViewTextBoxColumn.HeaderText = "Tipo";
            this.tipoDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.tipoDataGridViewTextBoxColumn.Name = "tipoDataGridViewTextBoxColumn";
            this.tipoDataGridViewTextBoxColumn.ReadOnly = true;
            this.tipoDataGridViewTextBoxColumn.Width = 125;
            // 
            // nomeDataGridViewTextBoxColumn
            // 
            this.nomeDataGridViewTextBoxColumn.DataPropertyName = "Nome";
            this.nomeDataGridViewTextBoxColumn.HeaderText = "Nome";
            this.nomeDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.nomeDataGridViewTextBoxColumn.Name = "nomeDataGridViewTextBoxColumn";
            this.nomeDataGridViewTextBoxColumn.ReadOnly = true;
            this.nomeDataGridViewTextBoxColumn.Width = 125;
            // 
            // cognomeDataGridViewTextBoxColumn
            // 
            this.cognomeDataGridViewTextBoxColumn.DataPropertyName = "Cognome";
            this.cognomeDataGridViewTextBoxColumn.HeaderText = "Cognome";
            this.cognomeDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.cognomeDataGridViewTextBoxColumn.Name = "cognomeDataGridViewTextBoxColumn";
            this.cognomeDataGridViewTextBoxColumn.ReadOnly = true;
            this.cognomeDataGridViewTextBoxColumn.Width = 125;
            // 
            // dataIngressoDataGridViewTextBoxColumn
            // 
            this.dataIngressoDataGridViewTextBoxColumn.DataPropertyName = "DataIngresso";
            this.dataIngressoDataGridViewTextBoxColumn.HeaderText = "DataIngresso";
            this.dataIngressoDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.dataIngressoDataGridViewTextBoxColumn.Name = "dataIngressoDataGridViewTextBoxColumn";
            this.dataIngressoDataGridViewTextBoxColumn.ReadOnly = true;
            this.dataIngressoDataGridViewTextBoxColumn.Width = 125;
            // 
            // dataUscitaDataGridViewTextBoxColumn
            // 
            this.dataUscitaDataGridViewTextBoxColumn.DataPropertyName = "DataUscita";
            this.dataUscitaDataGridViewTextBoxColumn.HeaderText = "DataUscita";
            this.dataUscitaDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.dataUscitaDataGridViewTextBoxColumn.Name = "dataUscitaDataGridViewTextBoxColumn";
            this.dataUscitaDataGridViewTextBoxColumn.ReadOnly = true;
            this.dataUscitaDataGridViewTextBoxColumn.Width = 125;
            // 
            // prezzoFinaleDataGridViewTextBoxColumn
            // 
            this.prezzoFinaleDataGridViewTextBoxColumn.DataPropertyName = "PrezzoFinale";
            this.prezzoFinaleDataGridViewTextBoxColumn.HeaderText = "PrezzoFinale";
            this.prezzoFinaleDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.prezzoFinaleDataGridViewTextBoxColumn.Name = "prezzoFinaleDataGridViewTextBoxColumn";
            this.prezzoFinaleDataGridViewTextBoxColumn.ReadOnly = true;
            this.prezzoFinaleDataGridViewTextBoxColumn.Width = 125;
            // 
            // posXDataGridViewTextBoxColumn
            // 
            this.posXDataGridViewTextBoxColumn.DataPropertyName = "PosX";
            this.posXDataGridViewTextBoxColumn.HeaderText = "PosX";
            this.posXDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.posXDataGridViewTextBoxColumn.Name = "posXDataGridViewTextBoxColumn";
            this.posXDataGridViewTextBoxColumn.ReadOnly = true;
            this.posXDataGridViewTextBoxColumn.Width = 125;
            // 
            // posYDataGridViewTextBoxColumn
            // 
            this.posYDataGridViewTextBoxColumn.DataPropertyName = "PosY";
            this.posYDataGridViewTextBoxColumn.HeaderText = "PosY";
            this.posYDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.posYDataGridViewTextBoxColumn.Name = "posYDataGridViewTextBoxColumn";
            this.posYDataGridViewTextBoxColumn.ReadOnly = true;
            this.posYDataGridViewTextBoxColumn.Width = 125;
            // 
            // viewStoricoBindingSource
            // 
            this.viewStoricoBindingSource.DataMember = "ViewStorico";
            this.viewStoricoBindingSource.DataSource = this.bindingStorico;
            // 
            // viewStoricoTableAdapter
            // 
            this.viewStoricoTableAdapter.ClearBeforeFill = true;
            // 
            // lbTitolo
            // 
            this.lbTitolo.BackColor = System.Drawing.Color.SkyBlue;
            this.lbTitolo.Dock = System.Windows.Forms.DockStyle.Top;
            this.lbTitolo.Font = new System.Drawing.Font("Copperplate Gothic Bold", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTitolo.Location = new System.Drawing.Point(0, 0);
            this.lbTitolo.Name = "lbTitolo";
            this.lbTitolo.Size = new System.Drawing.Size(1135, 37);
            this.lbTitolo.TabIndex = 2;
            this.lbTitolo.Text = "Parcheggio Storico";
            this.lbTitolo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // dateTimeCalc2
            // 
            this.dateTimeCalc2.Font = new System.Drawing.Font("Copperplate Gothic Light", 7F);
            this.dateTimeCalc2.Location = new System.Drawing.Point(486, 520);
            this.dateTimeCalc2.Name = "dateTimeCalc2";
            this.dateTimeCalc2.Size = new System.Drawing.Size(184, 20);
            this.dateTimeCalc2.TabIndex = 4;
            // 
            // dateTimeCalc1
            // 
            this.dateTimeCalc1.Font = new System.Drawing.Font("Copperplate Gothic Light", 7F);
            this.dateTimeCalc1.Location = new System.Drawing.Point(280, 520);
            this.dateTimeCalc1.Name = "dateTimeCalc1";
            this.dateTimeCalc1.Size = new System.Drawing.Size(183, 20);
            this.dateTimeCalc1.TabIndex = 5;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Copperplate Gothic Light", 9F);
            this.label1.Location = new System.Drawing.Point(2, 520);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(223, 16);
            this.label1.TabIndex = 6;
            this.label1.Text = "Calcolo gli incassi totali:";
            // 
            // dataSingola
            // 
            this.dataSingola.AutoSize = true;
            this.dataSingola.Font = new System.Drawing.Font("Copperplate Gothic Light", 8F);
            this.dataSingola.Location = new System.Drawing.Point(7, 550);
            this.dataSingola.Name = "dataSingola";
            this.dataSingola.Size = new System.Drawing.Size(132, 19);
            this.dataSingola.TabIndex = 9;
            this.dataSingola.TabStop = true;
            this.dataSingola.Text = "Data Singola";
            this.dataSingola.UseVisualStyleBackColor = true;
            this.dataSingola.CheckedChanged += new System.EventHandler(this.dataSingola_CheckedChanged);
            // 
            // dataDoppia
            // 
            this.dataDoppia.AutoSize = true;
            this.dataDoppia.Font = new System.Drawing.Font("Copperplate Gothic Light", 8F);
            this.dataDoppia.Location = new System.Drawing.Point(141, 551);
            this.dataDoppia.Name = "dataDoppia";
            this.dataDoppia.Size = new System.Drawing.Size(117, 19);
            this.dataDoppia.TabIndex = 10;
            this.dataDoppia.TabStop = true;
            this.dataDoppia.Text = "Range Date";
            this.dataDoppia.UseVisualStyleBackColor = true;
            this.dataDoppia.CheckedChanged += new System.EventHandler(this.dataDoppia_CheckedChanged);
            // 
            // btnIndietro
            // 
            this.btnIndietro.BackColor = System.Drawing.Color.MediumSlateBlue;
            this.btnIndietro.BackgroundColor = System.Drawing.Color.MediumSlateBlue;
            this.btnIndietro.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.btnIndietro.BorderRadius = 10;
            this.btnIndietro.BorderSize = 0;
            this.btnIndietro.FlatAppearance.BorderSize = 0;
            this.btnIndietro.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnIndietro.ForeColor = System.Drawing.Color.White;
            this.btnIndietro.Location = new System.Drawing.Point(1000, 544);
            this.btnIndietro.Name = "btnIndietro";
            this.btnIndietro.Size = new System.Drawing.Size(114, 26);
            this.btnIndietro.TabIndex = 8;
            this.btnIndietro.Text = "Indietro";
            this.btnIndietro.TextColor = System.Drawing.Color.White;
            this.btnIndietro.UseVisualStyleBackColor = false;
            this.btnIndietro.Click += new System.EventHandler(this.btnIndietro_Click);
            // 
            // calcola
            // 
            this.calcola.BackColor = System.Drawing.Color.MediumSlateBlue;
            this.calcola.BackgroundColor = System.Drawing.Color.MediumSlateBlue;
            this.calcola.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.calcola.BorderRadius = 10;
            this.calcola.BorderSize = 0;
            this.calcola.FlatAppearance.BorderSize = 0;
            this.calcola.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.calcola.ForeColor = System.Drawing.Color.White;
            this.calcola.Location = new System.Drawing.Point(280, 546);
            this.calcola.Name = "calcola";
            this.calcola.Size = new System.Drawing.Size(114, 26);
            this.calcola.TabIndex = 7;
            this.calcola.Text = "Calcola";
            this.calcola.TextColor = System.Drawing.Color.White;
            this.calcola.UseVisualStyleBackColor = false;
            this.calcola.Click += new System.EventHandler(this.calcola_Click);
            // 
            // formStorico
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SkyBlue;
            this.ClientSize = new System.Drawing.Size(1135, 581);
            this.Controls.Add(this.dataDoppia);
            this.Controls.Add(this.dataSingola);
            this.Controls.Add(this.btnIndietro);
            this.Controls.Add(this.calcola);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dateTimeCalc1);
            this.Controls.Add(this.dateTimeCalc2);
            this.Controls.Add(this.lbTitolo);
            this.Controls.Add(this.dataGridView1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "formStorico";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "formStorico";
            this.Load += new System.EventHandler(this.formStorico_Load);
            ((System.ComponentModel.ISupportInitialize)(this.bindingStorico)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.parcheggioDBDataSet7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewStoricoBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.BindingSource bindingStorico;
        private ParcheggioDBDataSet7 parcheggioDBDataSet7;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.BindingSource viewStoricoBindingSource;
        private ParcheggioDBDataSet7TableAdapters.ViewStoricoTableAdapter viewStoricoTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn targaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tipoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nomeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cognomeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataIngressoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataUscitaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn prezzoFinaleDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn posXDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn posYDataGridViewTextBoxColumn;
        private System.Windows.Forms.Label lbTitolo;
        private System.Windows.Forms.DateTimePicker dateTimeCalc2;
        private System.Windows.Forms.DateTimePicker dateTimeCalc1;
        private System.Windows.Forms.Label label1;
        private RJButton calcola;
        private RJButton btnIndietro;
        private System.Windows.Forms.RadioButton dataSingola;
        private System.Windows.Forms.RadioButton dataDoppia;
    }
}