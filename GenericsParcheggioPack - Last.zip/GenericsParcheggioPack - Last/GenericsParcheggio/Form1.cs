﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GenericsParcheggio
{
    public partial class Form1 : Form
    {
        List<string> posizione = new List<string>();
        Parcheggio p;
        int X;
        int Y;
        int widthButton;
        int heightButton;
        public Form1()
        {

            InitializeComponent();
            // TableLayoutPanel Initialization

            bool verifica = false;
            string connstring = "Server=DESKTOP-C85IVGL\\SQLEXPRESSNEW;Database=ParcheggioDB;User Id=sa;Password=Ciao*2002";
            using (SqlConnection connection = new SqlConnection(connstring))
            {
                connection.Open();
                string sqlinsert = "SELECT * FROM tblParcheggioCorrente";
                using (SqlCommand comando = new SqlCommand(sqlinsert, connection))
                {
                    SqlDataReader dr = comando.ExecuteReader();
                    if (dr.HasRows)
                        verifica = true;

                    dr.Close();
                }

                if (verifica)
                {
                    using (SqlCommand comando = new SqlCommand("dbo.spXmax", connection))
                    {
                        comando.CommandType = CommandType.StoredProcedure;
                        txtX.Value = Int16.Parse(comando.ExecuteScalar().ToString()) + 1;
                    }

                    using (SqlCommand comando = new SqlCommand("dbo.spYmax", connection))
                    {
                        comando.CommandType = CommandType.StoredProcedure;
                        txtY.Value = Int16.Parse(comando.ExecuteScalar().ToString()) + 1;
                    }


                    X = (int)txtX.Value;
                    Y = (int)txtY.Value;
                    int altezzaIniziale = lbRighe.Size.Height + lbTitolo.Size.Height;
                    int altezza = 0;
                    int cont = 0;
                    widthButton = panel1.Size.Width / Y;
                    heightButton = (panel1.Size.Height - altezzaIniziale) / X;
                    p = new Parcheggio(X, Y);
                    int tempMax = 0;
                    if (X > Y)
                        tempMax = X;
                    else
                        tempMax = Y;
                    int[] posPresentiRiga = new int[tempMax];
                    int[] posPresentiColonna = new int[tempMax];
                    const string sqlInsert2 = "SELECT V.Targa, V.Tipo, V.Coperto, V.PuliziaInterna, V.PuliziaEsterna, V.Parcheggiatore, Pr.Nome, Pr.Cognome, Pc.DataIngresso, Pc.PrezzoIniziale, Pc.PosX, Pc.PosY FROM tblParcheggioCorrente AS Pc JOIN tblVeicolo AS V ON Pc.IDVeicolo = V.IDVeicolo JOIN tblPersona AS Pr ON V.IDPersona = Pr.IDPersona";
                    int contPres = 0;
                    using (SqlCommand comando = new SqlCommand(sqlInsert2, connection))
                    {

                        SqlDataReader dr = null;
                        dr = comando.ExecuteReader();
                        while (dr.Read())
                        {
                            // Trovo la posizione delle auto già presenti nel database
                            if (dr["Nome"].ToString() != "")
                            {
                                posPresentiRiga[contPres] = Int16.Parse(dr["PosX"].ToString());
                                posPresentiColonna[contPres] = Int16.Parse(dr["PosY"].ToString());
                                contPres++;
                            }


                        }
                        dr.Close();
                    }
                    contPres = 0;
                    for (int j = 0; j < X; j++)
                    {
                        for (int i = 0; i < Y; i++)
                        {
                            cont++;
                            string tempPos = j.ToString() + "," + i.ToString();
                            posizione.Add(tempPos);
                            RJButton b = new RJButton();
                            b.Name = "btn" + cont.ToString();
                            b.Size = new Size(widthButton, heightButton);
                            b.Location = new Point(widthButton * i, altezzaIniziale + (heightButton * altezza));
                            b.BorderRadius = 20;
                            b.BackColor = Color.Green;
                            if (cont == 1)
                                b.BorderSize = 0;
                            b.Click += new EventHandler(clickPosto);
                            Image mg = Image.FromFile(@"\Users\Local\Desktop\GenericsParcheggioPack\freePark.PNG");
                            b.Image = mg;
                            b.ImageAlign = ContentAlignment.TopLeft;
                            panel1.Controls.Add(b);
                            using (SqlCommand comando = new SqlCommand(sqlInsert2, connection))
                            {

                                SqlDataReader dr = null;
                                dr = comando.ExecuteReader();
                                while (dr.Read())
                                {
                                    List<string> serviziAggiuntivi = new List<string>();

                                    if (dr["Nome"].ToString() != "" && Int16.Parse(dr["PosX"].ToString()) == j && Int16.Parse(dr["PosY"].ToString()) == i)
                                    {
                                        serviziAggiuntivi.Add(dr["Coperto"].ToString());
                                        serviziAggiuntivi.Add(dr["PuliziaInterna"].ToString());
                                        serviziAggiuntivi.Add(dr["PuliziaEsterna"].ToString());
                                        serviziAggiuntivi.Add(dr["Parcheggiatore"].ToString());

                                        p.EntraSetUp(dr["Targa"].ToString(), dr["Tipo"].ToString(), Int16.Parse(dr["PosX"].ToString()), Int16.Parse(dr["PosY"].ToString()), DateTime.Parse(dr["DataIngresso"].ToString()), dr["Nome"].ToString(), dr["Cognome"].ToString(), serviziAggiuntivi, b);
                                    }


                                }
                                dr.Close();
                            }




                        }
                        altezza++;
                    }
                    lbTarga.Enabled = true;
                    tbTarga.Enabled = true;
                    lbTipo.Enabled = true;
                    cbTipoVeicolo.Enabled = true;
                    lbNome.Enabled = true;
                    tbCognome.Enabled = true;
                    lbCognome.Enabled = true;
                    tbNome.Enabled = true;
                    lbIntestatario.Enabled = true;
                    checkBox1.Enabled = true;
                    checkBox2.Enabled = true;
                    checkBox3.Enabled = true;
                    checkBox4.Enabled = true;
                    lbDati.Enabled = true;
                    lbServizi.Enabled = true;
                    btnPulisci.Enabled = true;
                    lbRighe.Enabled = false;
                    lbColonne.Enabled = false;
                    txtX.Enabled = false;
                    txtY.Enabled = false;
                    lbSetUp.Enabled = false;
                    conferma.Enabled = false;
                }
            }





        }
        public void creaParcheggio()
        {
            X = (int)txtX.Value;
            Y = (int)txtY.Value;
            int altezzaIniziale = lbRighe.Size.Height + lbTitolo.Size.Height;
            int altezza = 0;
            int cont = 0;
            widthButton = panel1.Size.Width / Y;
            heightButton = (panel1.Size.Height - altezzaIniziale) / X;
            for (int j = 0; j < X; j++)
            {
                for (int i = 0; i < Y; i++)
                {
                    cont++;
                    string tempPos = j.ToString() + "," + i.ToString();
                    posizione.Add(tempPos);
                    RJButton b = new RJButton();
                    b.Name = "btn" + cont.ToString();
                    b.Size = new Size(widthButton, heightButton);
                    b.Location = new Point(widthButton * i, altezzaIniziale + (heightButton * altezza));
                    b.BorderRadius = 20;
                    b.BackColor = Color.Green;
                    if (cont == 1)
                        b.BorderSize = 0;
                    b.Click += new EventHandler(clickPosto);
                    Image mg = Image.FromFile(@"\Users\Local\Desktop\GenericsParcheggioPack\freePark.PNG");
                    b.Image = mg;
                    b.ImageAlign = ContentAlignment.TopLeft;

                    panel1.Controls.Add(b);

                }
                altezza++;
            }
            lbTarga.Enabled = true;
            tbTarga.Enabled = true;
            lbTipo.Enabled = true;
            cbTipoVeicolo.Enabled = true;
            lbNome.Enabled = true;
            tbCognome.Enabled = true;
            lbCognome.Enabled = true;
            tbNome.Enabled = true;
            lbIntestatario.Enabled = true;
            checkBox1.Enabled = true;
            checkBox2.Enabled = true;
            checkBox3.Enabled = true;
            checkBox4.Enabled = true;
            lbDati.Enabled = true;
            lbServizi.Enabled = true;
            btnPulisci.Enabled = true;
            lbRighe.Enabled = false;
            lbColonne.Enabled = false;
            txtX.Enabled = false;
            txtY.Enabled = false;
            lbSetUp.Enabled = false;
            conferma.Enabled = false;
        }

        private void conferma_Click(object sender, EventArgs e)
        {
            bool dimensioneX = true;
            bool dimensioneY = true;

            string riga = txtX.Text;
            for (int i = 0; i < txtX.Text.Length; i++)
                if ((int)riga[i] < 48 || (int)riga[i] > 57)
                {
                    dimensioneX = false;
                    break;
                }

            string colonna = txtY.Text;
            for (int i = 0; i < txtY.Text.Length; i++)
                if ((int)colonna[i] < 48 || (int)colonna[i] > 57)
                {
                    dimensioneY = false;
                    break;
                }


            if (!dimensioneX && !dimensioneY)
                MessageBox.Show("Inserire per il numero di righe e di colonne solo caratteri numerici.", "Attenzione", MessageBoxButtons.OK, MessageBoxIcon.Error);
            else if (!dimensioneX)
                MessageBox.Show("Inserire per il numero di righe solo caratteri numerici.", "Attenzione", MessageBoxButtons.OK, MessageBoxIcon.Error);
            else if (!dimensioneY)
                MessageBox.Show("Inserire per il numero di colonne solo caratteri numerici.", "Attenzione", MessageBoxButtons.OK, MessageBoxIcon.Error);
            else if ((int.Parse(txtX.Text) < 2 || int.Parse(txtX.Text) > 10) && (int.Parse(txtY.Text) < 2 || int.Parse(txtY.Text) > 10))
                MessageBox.Show("Dimensione minima: 2x2\nDimensione massima: 10x10", "Attenzione", MessageBoxButtons.OK, MessageBoxIcon.Error);
            else if (int.Parse(txtX.Text) < 2 || int.Parse(txtX.Text) > 10)
                MessageBox.Show("Numero minimo di righe: 2\nNumero massimo di righe: 10", "Attenzione", MessageBoxButtons.OK, MessageBoxIcon.Error);
            else if (int.Parse(txtY.Text) < 2 || int.Parse(txtY.Text) > 10)
                MessageBox.Show("Numero minimo di colonne: 2\nNumero massimo di colonne: 10", "Attenzione", MessageBoxButtons.OK, MessageBoxIcon.Error);
            else if (txtX.Text == "" && txtY.Text == "")
                MessageBox.Show("Inserire il numero di righe e il numero di colonne.", "Attenzione", MessageBoxButtons.OK, MessageBoxIcon.Error);
            else if (txtX.Text == "")
                MessageBox.Show("Inserire il numero di righe.", "Attenzione", MessageBoxButtons.OK, MessageBoxIcon.Error);
            else if (txtY.Text == "")
                MessageBox.Show("Inserire il numero di colonne.", "Attenzione", MessageBoxButtons.OK, MessageBoxIcon.Error);
            else if (txtX.Text == "")
                MessageBox.Show("Inserire il numero di righe.", "Attenzione", MessageBoxButtons.OK, MessageBoxIcon.Error);
            else if (txtX.Text == "")
                MessageBox.Show("Inserire il numero di righe.", "Attenzione", MessageBoxButtons.OK, MessageBoxIcon.Error);
            else
            {
                string connstring = "Server=DESKTOP-C85IVGL\\SQLEXPRESSNEW;Database=ParcheggioDB;User Id=sa;Password=Ciao*2002";
                using (SqlConnection connection = new SqlConnection(connstring))
                {
                    connection.Open();
                    const string sqlInsert = "INSERT INTO tblParcheggioCorrente (IDVeicolo, DataIngresso, PrezzoIniziale, PosX, PosY) VALUES (NULL, NULL, NULL, @PosX{0}, @PosY{0})";

                    using (SqlCommand comando = new SqlCommand())
                    {

                        int cont = 0;
                        string query = "";
                        comando.Connection = connection;
                        for (int i = 0; i < txtX.Value; i++)
                            for (int j = 0; j < txtY.Value; j++)
                            {
                                cont++;
                                query += string.Format(sqlInsert, cont);
                                comando.CommandText = query;
                                comando.Parameters.AddWithValue(string.Format("@PosX{0}", cont), i);
                                comando.Parameters.AddWithValue(string.Format("@PosY{0}", cont), j);
                                comando.ExecuteNonQuery();
                                query = "";
                            }
                    }


                }
                creaParcheggio();
            }



        }

        private void clickPosto(object sender, EventArgs e)
        {
            //double tariffaOraria = 7;
            p = new Parcheggio(X, Y);
            tbTarga.Text = tbTarga.Text.ToUpper();
            bool controlTarga = true;// variabile controllo corretto inserimento della targa
            bool controllTipo = false;// variabile controllo corretto inserimento del tipo di veicolo
            bool controlNomeCognome = true;
            string tempTarga = tbTarga.Text.ToUpper();
            Button btnTmp = (Button)sender;



            // Controllo il corretto inserimento della targa.
            if (tbTarga.Text.Length != 7)
                controlTarga = false;
            for (int i = 0; i < tbTarga.Text.Length; i++)
            {
                int converAscii = (int)tempTarga[i];
                if (!controlTarga)
                    break;
                if (i == 0 || i == 1 || i == 5 || i == 6)           // controllo che le prime e le ultime cifre della targa siano lettere
                {
                    if (converAscii < 65 || converAscii > 90)
                    {
                        controlTarga = false;
                        break;
                    }
                }
                if (i == 2 || i == 3 || i == 4)
                    if (converAscii < 48 || converAscii > 57)     // controllo che le cifre centrali della targa siano numeri
                    {
                        controlTarga = false;
                        break;
                    }
            }

            for (int i = 0; i < cbTipoVeicolo.Items.Count; i++)
                if (cbTipoVeicolo.Text == p.TariffaOraria.ElementAt(i).Key)
                {
                    Console.WriteLine(p.TariffaOraria.ElementAt(i).Key);
                    controllTipo = true;
                }

            foreach (Auto temp in Parcheggio.Macchine)
            {
                if (temp.Intestatario.Nome == tbNome.Text && temp.Intestatario.Cognome == tbCognome.Text && tbNome.Text != "" && tbCognome.Text != "")
                {
                    controlNomeCognome = false;
                    break;
                }
            }

            for (int i = 0; i < tbNome.Text.Length; i++)
            {
                int converAscii = (int)tbNome.Text[i];
                if (!controlNomeCognome)
                    break;

                if (converAscii < 65 || converAscii > 90 && converAscii < 97 || converAscii > 122)
                {
                    controlNomeCognome = false;
                    break;
                }

            }
            for (int i = 0; i < tbCognome.Text.Length; i++)
            {
                int converAscii = (int)tbCognome.Text[i];
                if (!controlNomeCognome)
                    break;

                if (converAscii < 65 || converAscii > 90 && converAscii < 97 || converAscii > 122)
                {
                    controlNomeCognome = false;
                    break;
                }

            }


            if ((controlTarga && controllTipo && controlNomeCognome) || btnTmp.BackColor == Color.Red)
            {
                List<string> ServizioAggiuntivo = new List<string>();
                if (checkBox1.Checked)
                    ServizioAggiuntivo.Add("Coperto");
                else
                    ServizioAggiuntivo.Add("NULL");
                if (checkBox2.Checked)
                    ServizioAggiuntivo.Add("Pulizia Interna");
                else
                    ServizioAggiuntivo.Add("NULL");
                if (checkBox3.Checked)
                    ServizioAggiuntivo.Add("Pulizia Esterna");
                else
                    ServizioAggiuntivo.Add("NULL");
                if (checkBox4.Checked)
                    ServizioAggiuntivo.Add("Parcheggiatore");
                else
                    ServizioAggiuntivo.Add("NULL");

                bool result = false;
                if (btnTmp.BackColor == Color.Green)
                {
                    var temporaneo = MessageBox.Show("Sei sicuro di voler parcheggiare l'auto?", "Info", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (temporaneo == DialogResult.Yes)
                        result = true;
                }
                else if (btnTmp.BackColor == Color.Red)
                {
                    var temporaneo = MessageBox.Show("Sei sicuro di voler lasciare il parcheggio?", "Info", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (temporaneo == DialogResult.Yes)
                        result = true;
                }
                if (btnTmp.BackColor == Color.Green && result)
                {
                    p.Entra(btnTmp, tbTarga.Text, posizione, cbTipoVeicolo.Text, tbNome.Text, tbCognome.Text, ServizioAggiuntivo);
                    //btnPulisci.Enabled = false;
                }
                else if (btnTmp.BackColor == Color.Red && result)
                {
                    p.Esci(btnTmp, posizione);
                    //btnPulisci.Enabled = true;

                }

            }
            else if (btnTmp.BackColor == Color.Green)
            {
                MessageBox.Show("Inserire correttamente tutti i parametri prima di parcheggiare.", "Attenzione", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }


        }

        private void btnPulisci_Click(object sender, EventArgs e)
        {
            tbNome.Text = "";
            tbCognome.Text = "";
            tbTarga.Text = "";
            checkBox1.Checked = false;
            checkBox2.Checked = false;
            checkBox3.Checked = false;
            checkBox4.Checked = false;
            cbTipoVeicolo.Text = "";

        }

        private void parcheggioCorrenteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            formCorrente formCorrente = new formCorrente();
            formCorrente.Show();
            this.Visible = false;

        }

        private void parcheggioStoricoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            formStorico formStorico = new formStorico();
            formStorico.Show();
            this.Visible = false;

        }

        private void informazioniToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Version 1.0.2.0", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void regoleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Regole regoleForm = new Regole();
            regoleForm.Show();
        }

        private void listinoPrezziToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ListinoPrezzi listinoPrezziForm = new ListinoPrezzi();
            listinoPrezziForm.Show();
        }

        private void nuovoParcheggioToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var temporaneo = MessageBox.Show("Premendo il tasto 'Sì' verrà resettato il database e verrà creato un nuovo parcheggio.", "Information", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (temporaneo == DialogResult.Yes)
            {
                string connstring = "Server=DESKTOP-C85IVGL\\SQLEXPRESSNEW;Database=ParcheggioDB;User Id=sa;Password=Ciao*2002";
                using (SqlConnection connection = new SqlConnection(connstring))
                {
                    connection.Open();
                    const string sqlInsert = "DELETE FROM tblParcheggioCorrente";

                    using (SqlCommand comando = new SqlCommand(sqlInsert, connection))
                    {
                        comando.ExecuteNonQuery();

                        comando.CommandText = "DELETE FROM tblParcheggioStorico";
                        comando.ExecuteNonQuery();

                        comando.CommandText = "DELETE FROM tblPersona";
                        comando.ExecuteNonQuery();

                        comando.CommandText = "DELETE FROM tblVeicolo";
                        comando.ExecuteNonQuery();

                        comando.CommandText = "DBCC CHECKIDENT(tblParcheggioCorrente, RESEED, 0)";
                        comando.ExecuteNonQuery();

                        comando.CommandText = "DBCC CHECKIDENT(tblParcheggioStorico, RESEED, 0)";
                        comando.ExecuteNonQuery();

                        comando.CommandText = "DBCC CHECKIDENT(tblPersona, RESEED, 0)";
                        comando.ExecuteNonQuery();

                        comando.CommandText = "DBCC CHECKIDENT(tblVeicolo, RESEED, 0)";
                        comando.ExecuteNonQuery();

                        Application.Restart();
                    }
                }
            }

        }


    }

}


