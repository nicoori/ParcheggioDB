﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GenericsParcheggio
{
    public partial class formStorico : Form
    {
        public formStorico()
        {
            InitializeComponent();
        }

        private void formStorico_Load(object sender, EventArgs e)
        {
            // TODO: questa riga di codice carica i dati nella tabella 'parcheggioDBDataSet7.ViewStorico'. È possibile spostarla o rimuoverla se necessario.
            this.viewStoricoTableAdapter.Fill(this.parcheggioDBDataSet7.ViewStorico);

        }

        private void btnIndietro_Click(object sender, EventArgs e)
        {
            this.Close();
            Form1 form1 = new Form1();
            form1.Show();
        }

        private void calcola_Click(object sender, EventArgs e)
        {
            if(dataSingola.Checked)
            {
                string connstring2 = "Server=DESKTOP-C85IVGL\\SQLEXPRESSNEW;Database=ParcheggioDB;User Id=sa;Password=Ciao*2002";
                using (SqlConnection connection = new SqlConnection(connstring2))
                {
                    connection.Open();
                    using (SqlCommand comando = new SqlCommand())
                    {
                        comando.CommandText = "SELECT SUM(PrezzoFinale) FROM tblParcheggioStorico WHERE DAY(DataUscita) = DAY(@dataUscita) AND MONTH(DataUscita) = MONTH(@dataUscita) AND YEAR(DataUscita) = YEAR(@dataUscita)";
                        comando.Connection = connection;
                        comando.Parameters.AddWithValue("@dataUscita", dateTimeCalc1.Value);

                        if (comando.ExecuteScalar().ToString() != "")
                        {
                            double incasso = double.Parse(comando.ExecuteScalar().ToString());
                            string message = "Incassi giornalieri totali: " + incasso + "€";
                            MessageBox.Show(message, "Incassi", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        else
                            MessageBox.Show("Non sono presenti incassi nella data selezionata.", "Attenzione", MessageBoxButtons.OK, MessageBoxIcon.Error);


                    }
                }
            }
            else
            {
                string connstring2 = "Server=DESKTOP-C85IVGL\\SQLEXPRESSNEW;Database=ParcheggioDB;User Id=sa;Password=Ciao*2002";
                using (SqlConnection connection = new SqlConnection(connstring2))
                {
                    connection.Open();
                    using (SqlCommand comando = new SqlCommand())
                    {
                        var differenzaDate = dateTimeCalc2.Value.Day - dateTimeCalc1.Value.Day;
                        if(differenzaDate < 0)
                        {
                            var box = dateTimeCalc2.Value;
                            dateTimeCalc2.Value = dateTimeCalc1.Value;
                            dateTimeCalc1.Value = box;
                        }
                        comando.CommandText = "SELECT SUM(PrezzoFinale) FROM tblParcheggioStorico WHERE CONVERT(DATE, DataUscita) BETWEEN CONVERT(DATE, @date1) AND CONVERT(DATE, @date2)";
                        comando.Connection = connection;
                        comando.Parameters.AddWithValue("@date1", dateTimeCalc1.Value);
                        comando.Parameters.AddWithValue("@date2", dateTimeCalc2.Value);
                        if (comando.ExecuteScalar().ToString() != "")
                        {
                            double incasso = double.Parse(comando.ExecuteScalar().ToString());
                            string message = "Incassi totali tra " + dateTimeCalc1.Value.ToShortDateString() + " e " + dateTimeCalc2.Value.ToShortDateString() + ": " + incasso + "€";
                            MessageBox.Show(message, "Incassi", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        else
                            MessageBox.Show("Non sono presenti incassi nella data selezionata.", "Attenzione", MessageBoxButtons.OK, MessageBoxIcon.Error);

                    }
                }
            }
            
        }

        private void dataSingola_CheckedChanged(object sender, EventArgs e)
        {
            dateTimeCalc2.Visible = false;
        }

        private void dataDoppia_CheckedChanged(object sender, EventArgs e)
        {
            dateTimeCalc2.Visible = true;

        }
    }
}
