﻿
namespace GenericsParcheggio
{
    partial class Form1
    {
        /// <summary>
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Pulire le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione Windows Form

        /// <summary>
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.panel1 = new System.Windows.Forms.Panel();
            this.lbTitolo = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.visualizzaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.parcheggioCorrenteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.parcheggioStoricoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tariffeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.listinoPrezziToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.istruzioniToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.regoleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.resetToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nuovoParcheggioToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.informazioniToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panelDown = new System.Windows.Forms.Panel();
            this.txtY = new System.Windows.Forms.NumericUpDown();
            this.txtX = new System.Windows.Forms.NumericUpDown();
            this.btnPulisci = new System.Windows.Forms.Button();
            this.lbCognome = new System.Windows.Forms.Label();
            this.lbNome = new System.Windows.Forms.Label();
            this.tbCognome = new System.Windows.Forms.TextBox();
            this.tbNome = new System.Windows.Forms.TextBox();
            this.lbIntestatario = new System.Windows.Forms.Label();
            this.lbServizi = new System.Windows.Forms.Label();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.cbTipoVeicolo = new System.Windows.Forms.ComboBox();
            this.lbTipo = new System.Windows.Forms.Label();
            this.lbDati = new System.Windows.Forms.Label();
            this.lbSetUp = new System.Windows.Forms.Label();
            this.conferma = new System.Windows.Forms.Button();
            this.lbTarga = new System.Windows.Forms.Label();
            this.lbColonne = new System.Windows.Forms.Label();
            this.lbRighe = new System.Windows.Forms.Label();
            this.tbTarga = new System.Windows.Forms.TextBox();
            this.panel1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.panelDown.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtY)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtX)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.lbTitolo);
            this.panel1.Controls.Add(this.menuStrip1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1058, 549);
            this.panel1.TabIndex = 7;
            // 
            // lbTitolo
            // 
            this.lbTitolo.BackColor = System.Drawing.SystemColors.Menu;
            this.lbTitolo.Font = new System.Drawing.Font("Copperplate Gothic Bold", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTitolo.Location = new System.Drawing.Point(357, 0);
            this.lbTitolo.Name = "lbTitolo";
            this.lbTitolo.Size = new System.Drawing.Size(313, 37);
            this.lbTitolo.TabIndex = 0;
            this.lbTitolo.Text = "Online Parking";
            this.lbTitolo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // menuStrip1
            // 
            this.menuStrip1.AutoSize = false;
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.visualizzaToolStripMenuItem,
            this.tariffeToolStripMenuItem,
            this.istruzioniToolStripMenuItem,
            this.resetToolStripMenuItem,
            this.aboutToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1058, 37);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // visualizzaToolStripMenuItem
            // 
            this.visualizzaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.parcheggioCorrenteToolStripMenuItem,
            this.parcheggioStoricoToolStripMenuItem});
            this.visualizzaToolStripMenuItem.Name = "visualizzaToolStripMenuItem";
            this.visualizzaToolStripMenuItem.Size = new System.Drawing.Size(88, 33);
            this.visualizzaToolStripMenuItem.Text = "Visualizza";
            // 
            // parcheggioCorrenteToolStripMenuItem
            // 
            this.parcheggioCorrenteToolStripMenuItem.Name = "parcheggioCorrenteToolStripMenuItem";
            this.parcheggioCorrenteToolStripMenuItem.Size = new System.Drawing.Size(227, 26);
            this.parcheggioCorrenteToolStripMenuItem.Text = "Parcheggio Corrente";
            this.parcheggioCorrenteToolStripMenuItem.Click += new System.EventHandler(this.parcheggioCorrenteToolStripMenuItem_Click);
            // 
            // parcheggioStoricoToolStripMenuItem
            // 
            this.parcheggioStoricoToolStripMenuItem.Name = "parcheggioStoricoToolStripMenuItem";
            this.parcheggioStoricoToolStripMenuItem.Size = new System.Drawing.Size(227, 26);
            this.parcheggioStoricoToolStripMenuItem.Text = "Parcheggio Storico";
            this.parcheggioStoricoToolStripMenuItem.Click += new System.EventHandler(this.parcheggioStoricoToolStripMenuItem_Click);
            // 
            // tariffeToolStripMenuItem
            // 
            this.tariffeToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.listinoPrezziToolStripMenuItem});
            this.tariffeToolStripMenuItem.Name = "tariffeToolStripMenuItem";
            this.tariffeToolStripMenuItem.Size = new System.Drawing.Size(64, 33);
            this.tariffeToolStripMenuItem.Text = "Tariffe";
            // 
            // listinoPrezziToolStripMenuItem
            // 
            this.listinoPrezziToolStripMenuItem.Name = "listinoPrezziToolStripMenuItem";
            this.listinoPrezziToolStripMenuItem.Size = new System.Drawing.Size(178, 26);
            this.listinoPrezziToolStripMenuItem.Text = "Listino Prezzi";
            this.listinoPrezziToolStripMenuItem.Click += new System.EventHandler(this.listinoPrezziToolStripMenuItem_Click);
            // 
            // istruzioniToolStripMenuItem
            // 
            this.istruzioniToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.regoleToolStripMenuItem});
            this.istruzioniToolStripMenuItem.Name = "istruzioniToolStripMenuItem";
            this.istruzioniToolStripMenuItem.Size = new System.Drawing.Size(83, 33);
            this.istruzioniToolStripMenuItem.Text = "Istruzioni";
            // 
            // regoleToolStripMenuItem
            // 
            this.regoleToolStripMenuItem.Name = "regoleToolStripMenuItem";
            this.regoleToolStripMenuItem.Size = new System.Drawing.Size(139, 26);
            this.regoleToolStripMenuItem.Text = "Regole";
            this.regoleToolStripMenuItem.Click += new System.EventHandler(this.regoleToolStripMenuItem_Click);
            // 
            // resetToolStripMenuItem
            // 
            this.resetToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.nuovoParcheggioToolStripMenuItem});
            this.resetToolStripMenuItem.Name = "resetToolStripMenuItem";
            this.resetToolStripMenuItem.Size = new System.Drawing.Size(59, 33);
            this.resetToolStripMenuItem.Text = "Reset";
            // 
            // nuovoParcheggioToolStripMenuItem
            // 
            this.nuovoParcheggioToolStripMenuItem.Name = "nuovoParcheggioToolStripMenuItem";
            this.nuovoParcheggioToolStripMenuItem.Size = new System.Drawing.Size(214, 26);
            this.nuovoParcheggioToolStripMenuItem.Text = "Nuovo Parcheggio";
            this.nuovoParcheggioToolStripMenuItem.Click += new System.EventHandler(this.nuovoParcheggioToolStripMenuItem_Click);
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.informazioniToolStripMenuItem});
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(64, 33);
            this.aboutToolStripMenuItem.Text = "About";
            // 
            // informazioniToolStripMenuItem
            // 
            this.informazioniToolStripMenuItem.Name = "informazioniToolStripMenuItem";
            this.informazioniToolStripMenuItem.Size = new System.Drawing.Size(176, 26);
            this.informazioniToolStripMenuItem.Text = "Informazioni";
            this.informazioniToolStripMenuItem.Click += new System.EventHandler(this.informazioniToolStripMenuItem_Click);
            // 
            // panelDown
            // 
            this.panelDown.Controls.Add(this.txtY);
            this.panelDown.Controls.Add(this.txtX);
            this.panelDown.Controls.Add(this.btnPulisci);
            this.panelDown.Controls.Add(this.lbCognome);
            this.panelDown.Controls.Add(this.lbNome);
            this.panelDown.Controls.Add(this.tbCognome);
            this.panelDown.Controls.Add(this.tbNome);
            this.panelDown.Controls.Add(this.lbIntestatario);
            this.panelDown.Controls.Add(this.lbServizi);
            this.panelDown.Controls.Add(this.checkBox4);
            this.panelDown.Controls.Add(this.checkBox3);
            this.panelDown.Controls.Add(this.checkBox2);
            this.panelDown.Controls.Add(this.checkBox1);
            this.panelDown.Controls.Add(this.cbTipoVeicolo);
            this.panelDown.Controls.Add(this.lbTipo);
            this.panelDown.Controls.Add(this.lbDati);
            this.panelDown.Controls.Add(this.lbSetUp);
            this.panelDown.Controls.Add(this.conferma);
            this.panelDown.Controls.Add(this.lbTarga);
            this.panelDown.Controls.Add(this.lbColonne);
            this.panelDown.Controls.Add(this.lbRighe);
            this.panelDown.Controls.Add(this.tbTarga);
            this.panelDown.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelDown.Location = new System.Drawing.Point(0, 555);
            this.panelDown.Name = "panelDown";
            this.panelDown.Size = new System.Drawing.Size(1058, 182);
            this.panelDown.TabIndex = 8;
            // 
            // txtY
            // 
            this.txtY.Location = new System.Drawing.Point(96, 102);
            this.txtY.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.txtY.Minimum = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.txtY.Name = "txtY";
            this.txtY.Size = new System.Drawing.Size(151, 22);
            this.txtY.TabIndex = 32;
            this.txtY.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            // 
            // txtX
            // 
            this.txtX.Location = new System.Drawing.Point(96, 52);
            this.txtX.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.txtX.Minimum = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.txtX.Name = "txtX";
            this.txtX.Size = new System.Drawing.Size(151, 22);
            this.txtX.TabIndex = 31;
            this.txtX.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            // 
            // btnPulisci
            // 
            this.btnPulisci.Enabled = false;
            this.btnPulisci.Font = new System.Drawing.Font("Copperplate Gothic Light", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPulisci.Location = new System.Drawing.Point(895, 143);
            this.btnPulisci.Name = "btnPulisci";
            this.btnPulisci.Size = new System.Drawing.Size(151, 27);
            this.btnPulisci.TabIndex = 30;
            this.btnPulisci.Text = "Pulisci";
            this.btnPulisci.UseVisualStyleBackColor = true;
            this.btnPulisci.Click += new System.EventHandler(this.btnPulisci_Click);
            // 
            // lbCognome
            // 
            this.lbCognome.AutoSize = true;
            this.lbCognome.Enabled = false;
            this.lbCognome.Font = new System.Drawing.Font("Copperplate Gothic Light", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbCognome.Location = new System.Drawing.Point(806, 109);
            this.lbCognome.Name = "lbCognome";
            this.lbCognome.Size = new System.Drawing.Size(80, 15);
            this.lbCognome.TabIndex = 29;
            this.lbCognome.Text = "Cognome";
            // 
            // lbNome
            // 
            this.lbNome.AutoSize = true;
            this.lbNome.Enabled = false;
            this.lbNome.Font = new System.Drawing.Font("Copperplate Gothic Light", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbNome.Location = new System.Drawing.Point(833, 56);
            this.lbNome.Name = "lbNome";
            this.lbNome.Size = new System.Drawing.Size(49, 15);
            this.lbNome.TabIndex = 28;
            this.lbNome.Text = "Nome";
            // 
            // tbCognome
            // 
            this.tbCognome.Enabled = false;
            this.tbCognome.Location = new System.Drawing.Point(895, 104);
            this.tbCognome.Name = "tbCognome";
            this.tbCognome.Size = new System.Drawing.Size(151, 22);
            this.tbCognome.TabIndex = 27;
            // 
            // tbNome
            // 
            this.tbNome.Enabled = false;
            this.tbNome.Location = new System.Drawing.Point(895, 51);
            this.tbNome.Name = "tbNome";
            this.tbNome.Size = new System.Drawing.Size(151, 22);
            this.tbNome.TabIndex = 26;
            // 
            // lbIntestatario
            // 
            this.lbIntestatario.Enabled = false;
            this.lbIntestatario.Font = new System.Drawing.Font("Copperplate Gothic Light", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbIntestatario.Location = new System.Drawing.Point(893, 18);
            this.lbIntestatario.Name = "lbIntestatario";
            this.lbIntestatario.Size = new System.Drawing.Size(153, 23);
            this.lbIntestatario.TabIndex = 25;
            this.lbIntestatario.Text = "Intestatario";
            this.lbIntestatario.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbServizi
            // 
            this.lbServizi.AutoSize = true;
            this.lbServizi.Enabled = false;
            this.lbServizi.Font = new System.Drawing.Font("Copperplate Gothic Light", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbServizi.Location = new System.Drawing.Point(596, 26);
            this.lbServizi.Name = "lbServizi";
            this.lbServizi.Size = new System.Drawing.Size(137, 15);
            this.lbServizi.TabIndex = 24;
            this.lbServizi.Text = "Servizi aggiuntivi";
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.Enabled = false;
            this.checkBox4.Location = new System.Drawing.Point(599, 125);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(127, 21);
            this.checkBox4.TabIndex = 23;
            this.checkBox4.Text = "Parcheggiatore";
            this.checkBox4.UseVisualStyleBackColor = true;
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Enabled = false;
            this.checkBox3.Location = new System.Drawing.Point(599, 98);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(124, 21);
            this.checkBox3.TabIndex = 22;
            this.checkBox3.Text = "Pulizia Esterna";
            this.checkBox3.UseVisualStyleBackColor = true;
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Enabled = false;
            this.checkBox2.Location = new System.Drawing.Point(599, 71);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(119, 21);
            this.checkBox2.TabIndex = 21;
            this.checkBox2.Text = "Pulizia Interna";
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Enabled = false;
            this.checkBox1.Location = new System.Drawing.Point(599, 44);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(80, 21);
            this.checkBox1.TabIndex = 20;
            this.checkBox1.Text = "Coperto";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // cbTipoVeicolo
            // 
            this.cbTipoVeicolo.Enabled = false;
            this.cbTipoVeicolo.FormattingEnabled = true;
            this.cbTipoVeicolo.Items.AddRange(new object[] {
            "Utilitaria",
            "Berlina",
            "Auto Sportiva",
            "Familiare",
            "Suv",
            "Pick-Up",
            "Camion"});
            this.cbTipoVeicolo.Location = new System.Drawing.Point(410, 104);
            this.cbTipoVeicolo.Name = "cbTipoVeicolo";
            this.cbTipoVeicolo.Size = new System.Drawing.Size(151, 24);
            this.cbTipoVeicolo.TabIndex = 19;
            // 
            // lbTipo
            // 
            this.lbTipo.AutoSize = true;
            this.lbTipo.Enabled = false;
            this.lbTipo.Font = new System.Drawing.Font("Copperplate Gothic Light", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTipo.Location = new System.Drawing.Point(299, 109);
            this.lbTipo.Name = "lbTipo";
            this.lbTipo.Size = new System.Drawing.Size(105, 15);
            this.lbTipo.TabIndex = 18;
            this.lbTipo.Text = "Tipo Veicolo";
            // 
            // lbDati
            // 
            this.lbDati.Enabled = false;
            this.lbDati.Font = new System.Drawing.Font("Copperplate Gothic Light", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbDati.Location = new System.Drawing.Point(369, 18);
            this.lbDati.Name = "lbDati";
            this.lbDati.Size = new System.Drawing.Size(207, 23);
            this.lbDati.TabIndex = 16;
            this.lbDati.Text = "Dati Automobile";
            this.lbDati.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbSetUp
            // 
            this.lbSetUp.Font = new System.Drawing.Font("Copperplate Gothic Light", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbSetUp.Location = new System.Drawing.Point(33, 18);
            this.lbSetUp.Name = "lbSetUp";
            this.lbSetUp.Size = new System.Drawing.Size(214, 23);
            this.lbSetUp.TabIndex = 15;
            this.lbSetUp.Text = "SetUp";
            this.lbSetUp.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // conferma
            // 
            this.conferma.Font = new System.Drawing.Font("Copperplate Gothic Light", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.conferma.Location = new System.Drawing.Point(96, 143);
            this.conferma.Name = "conferma";
            this.conferma.Size = new System.Drawing.Size(151, 27);
            this.conferma.TabIndex = 13;
            this.conferma.Text = "conferma";
            this.conferma.UseVisualStyleBackColor = true;
            this.conferma.Click += new System.EventHandler(this.conferma_Click);
            // 
            // lbTarga
            // 
            this.lbTarga.AutoSize = true;
            this.lbTarga.Enabled = false;
            this.lbTarga.Font = new System.Drawing.Font("Copperplate Gothic Light", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTarga.Location = new System.Drawing.Point(351, 56);
            this.lbTarga.Name = "lbTarga";
            this.lbTarga.Size = new System.Drawing.Size(53, 15);
            this.lbTarga.TabIndex = 12;
            this.lbTarga.Text = "Targa";
            // 
            // lbColonne
            // 
            this.lbColonne.AutoSize = true;
            this.lbColonne.Font = new System.Drawing.Font("Copperplate Gothic Light", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbColonne.Location = new System.Drawing.Point(7, 109);
            this.lbColonne.Name = "lbColonne";
            this.lbColonne.Size = new System.Drawing.Size(77, 15);
            this.lbColonne.TabIndex = 11;
            this.lbColonne.Text = "Colonne";
            // 
            // lbRighe
            // 
            this.lbRighe.AutoSize = true;
            this.lbRighe.Font = new System.Drawing.Font("Copperplate Gothic Light", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbRighe.Location = new System.Drawing.Point(34, 56);
            this.lbRighe.Name = "lbRighe";
            this.lbRighe.Size = new System.Drawing.Size(50, 15);
            this.lbRighe.TabIndex = 10;
            this.lbRighe.Text = "Righe";
            // 
            // tbTarga
            // 
            this.tbTarga.Enabled = false;
            this.tbTarga.Location = new System.Drawing.Point(410, 51);
            this.tbTarga.Name = "tbTarga";
            this.tbTarga.Size = new System.Drawing.Size(151, 22);
            this.tbTarga.TabIndex = 9;
            // 
            // Form1
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Inherit;
            this.BackColor = System.Drawing.Color.SkyBlue;
            this.ClientSize = new System.Drawing.Size(1058, 737);
            this.Controls.Add(this.panelDown);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Parking Area";
            this.panel1.ResumeLayout(false);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panelDown.ResumeLayout(false);
            this.panelDown.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtY)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtX)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panelDown;
        private System.Windows.Forms.Button conferma;
        private System.Windows.Forms.Label lbTarga;
        private System.Windows.Forms.Label lbColonne;
        private System.Windows.Forms.Label lbRighe;
        private System.Windows.Forms.TextBox tbTarga;
        private System.Windows.Forms.Label lbSetUp;
        private System.Windows.Forms.Label lbDati;
        private System.Windows.Forms.Label lbTipo;
        private System.Windows.Forms.ComboBox cbTipoVeicolo;
        private System.Windows.Forms.Label lbCognome;
        private System.Windows.Forms.Label lbNome;
        private System.Windows.Forms.TextBox tbCognome;
        private System.Windows.Forms.TextBox tbNome;
        private System.Windows.Forms.Label lbIntestatario;
        private System.Windows.Forms.Label lbServizi;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Label lbTitolo;
        private System.Windows.Forms.Button btnPulisci;
        private System.Windows.Forms.NumericUpDown txtY;
        private System.Windows.Forms.NumericUpDown txtX;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem visualizzaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem parcheggioCorrenteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem parcheggioStoricoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem informazioniToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem istruzioniToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem regoleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tariffeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem listinoPrezziToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem resetToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem nuovoParcheggioToolStripMenuItem;
    }
}

