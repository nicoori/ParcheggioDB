﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenericsParcheggio
{
    public class Auto
    {
        public string Targa { get; set; }
        public DateTime OraIngresso { get; set; }
        public double PrezzoTotale { get; set; }
        public string TipoVeicolo { get; set; }

        public List<string> ServizioAggiuntivo = new List<string>();
        public Intestatario Intestatario;
        public Point point;

        public Auto(string targa, DateTime oraingresso, int riga, int colonna, double prezzoTotale, string tipoVeicolo, List<string> servizioAggiuntivo, string nome, string cognome)
        {
            Targa = targa;
            OraIngresso = oraingresso;
            point = new Point(riga, colonna);
            PrezzoTotale = prezzoTotale;
            TipoVeicolo = tipoVeicolo;
            foreach(string i in servizioAggiuntivo)
            {
                ServizioAggiuntivo.Add(i);
            }
            Intestatario = new Intestatario(nome, cognome);
        }
    }
}
