﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GenericsParcheggio
{
    public class Parcheggio
    {
        Dictionary<string, bool> statoParcheggio = new Dictionary<string, bool>();

        public int NumeroColonne { get; set; }
        public int NumeroRighe { get; set; }
        static public List<Auto> Macchine = new List<Auto>();
        //public double TariffaOraria { get; set; }
        public Dictionary<string, double> TariffaOraria = new Dictionary<string, double>();
        public Dictionary<string, double> TariffaServizi = new Dictionary<string, double>();

        public Parcheggio(int numerocolonne, int numerorighe)
        {
            NumeroColonne = numerocolonne;
            NumeroRighe = numerorighe;
            TariffaOraria.Add("Utilitaria", 7.5);
            TariffaOraria.Add("Berlina", 8);
            TariffaOraria.Add("Auto Sportiva", 10);
            TariffaOraria.Add("Familiare", 8.5);
            TariffaOraria.Add("Suv", 10.5);
            TariffaOraria.Add("Pick-Up", 11);
            TariffaOraria.Add("Camion", 11.5);
            TariffaServizi.Add("Coperto", 5);
            TariffaServizi.Add("Pulizia Interna", 7);
            TariffaServizi.Add("Pulizia Esterna", 6);
            TariffaServizi.Add("Parcheggiatore", 3);

        }

        public int[] Entra(Button btnTmp, string tbTarga, List<string> posizione, string tipoVeicolo, string nome, string cognome, List<string> ServizioAggiuntivo)
        {
            // controllo che la macchina inserita non sia già presente.
            Console.WriteLine(tbTarga);
            bool control = true;
            foreach (Auto a in Macchine)
            {
                if (tbTarga == a.Targa)
                    control = false;
            }

            // Ricavo la posizione del bottone
            if (control)
            {
                string convert = Regex.Match(btnTmp.Name, @"\d+").Value;
                int x = 0;
                int y = 0;
                int cont = 0;
                string[] words = posizione[Int32.Parse(convert) - 1].Split(',');
                foreach (string s in words)
                {
                    if (cont == 0)
                        x = Int32.Parse(s);
                    else
                        y = Int32.Parse(s);
                    cont++;
                }

                DateTime oraIngresso = new DateTime();
                oraIngresso = DateTime.Now;
                double tempServizi = 0;
                for (int i = 0; i < ServizioAggiuntivo.Count; i++)
                    for (int j = 0; j < TariffaServizi.Count; j++)
                        if (ServizioAggiuntivo[i] == TariffaServizi.ElementAt(j).Key)
                            tempServizi += TariffaServizi[ServizioAggiuntivo[i]];

                Console.WriteLine("\n\n" + tempServizi + "\n\n");
                Auto m = new Auto(tbTarga, oraIngresso, x, y, tempServizi, tipoVeicolo, ServizioAggiuntivo, nome, cognome);
                Macchine.Add(m);
                Image mg = Image.FromFile(@"C:\Users\Local\Desktop\GenericsParcheggioPack\car.PNG");
                btnTmp.ImageAlign = ContentAlignment.MiddleCenter;
                btnTmp.Image = mg;
                int tempStampaRiga = m.point.X + 1;
                int tempStampaCol = m.point.Y + 1;
                string message = m.Intestatario.Cognome + " " + m.Intestatario.Nome + "\nHai parcheggiato qui la macchina " + m.Targa + " in data: " + m.OraIngresso + "\nPosizione: " + tempStampaRiga + "," + tempStampaCol;
                MessageBox.Show(message, "Park", MessageBoxButtons.OK, MessageBoxIcon.Information);
                statoParcheggio.Add(m.Targa, true);
                btnTmp.BackColor = Color.Red;
                btnTmp.Text = m.Targa;
                btnTmp.TextAlign = ContentAlignment.TopLeft;
                int[] tempPos = new int[2];
                tempPos[0] = m.point.X;
                tempPos[1] = m.point.Y;

                SqlConnection.ClearAllPools();
                string connstring2 = "Server=DESKTOP-C85IVGL\\SQLEXPRESSNEW;Database=ParcheggioDB;User Id=sa;Password=Ciao*2002";
                using (SqlConnection connection2 = new SqlConnection(connstring2))
                {
                    connection2.Open();
                    using (SqlCommand comando = new SqlCommand())
                    {

                        comando.Connection = connection2;
                        comando.CommandText = "INSERT INTO tblPersona (Nome, Cognome) VALUES (@Nome, @Cognome)";
                        comando.Parameters.AddWithValue("@Nome", m.Intestatario.Nome);
                        comando.Parameters.AddWithValue("@Cognome", m.Intestatario.Cognome);
                        comando.ExecuteNonQuery();

                        comando.CommandText = "SELECT IDPersona FROM tblPersona WHERE Nome = @Nome1 AND Cognome = @Cognome1";
                        comando.Parameters.AddWithValue("@Nome1", m.Intestatario.Nome);
                        comando.Parameters.AddWithValue("@Cognome1", m.Intestatario.Cognome);
                        int IDPersona1 = Int16.Parse(comando.ExecuteScalar().ToString());
                        comando.CommandText = "INSERT INTO tblVeicolo (IDPersona, Targa, Tipo, Coperto, PuliziaInterna, PuliziaEsterna, Parcheggiatore) VALUES (@IDPersona, @Targa, @Tipo, @Coperto, @Interno, @Esterno, @Parcheggiatore)";
                        comando.Parameters.AddWithValue("@IDPersona", IDPersona1);
                        comando.Parameters.AddWithValue("@Targa", m.Targa);
                        comando.Parameters.AddWithValue("@Tipo", m.TipoVeicolo);
                        int contaServ = 0;
                        foreach (string i in ServizioAggiuntivo)
                        {
                            if (contaServ == 0)
                                comando.Parameters.AddWithValue("@Coperto", i);

                            if (contaServ == 1)
                                comando.Parameters.AddWithValue("@Interno", i);

                            if (contaServ == 2)
                                comando.Parameters.AddWithValue("@Esterno", i);

                            if (contaServ == 3)
                                comando.Parameters.AddWithValue("@Parcheggiatore", i);

                            contaServ++;
                        }
                        comando.ExecuteNonQuery();

                        comando.CommandText = "SELECT IDVeicolo FROM tblVeicolo WHERE Targa = @Targa2";
                        comando.Parameters.AddWithValue("@Targa2", m.Targa);
                        SqlDataReader dr = null;
                        dr = comando.ExecuteReader();
                        int IDVeicolo = 0;
                        int tempIDVeicolo = 0;

                        while (dr.Read())
                        {
                            tempIDVeicolo = Int16.Parse(dr["IDVeicolo"].ToString());
                            Console.WriteLine("\n" + Int16.Parse(dr["IDVeicolo"].ToString()) + " " + IDVeicolo);

                        }
                        IDVeicolo = tempIDVeicolo;
                        dr.Close();

                        comando.CommandText = "SELECT IDPersona FROM tblPersona WHERE Nome = @Nome2 AND Cognome = @Cognome2";
                        comando.Parameters.AddWithValue("@Nome2", m.Intestatario.Nome);
                        comando.Parameters.AddWithValue("@Cognome2", m.Intestatario.Cognome);
                        SqlDataReader dr2 = null;
                        dr2 = comando.ExecuteReader();
                        int IDPersona = 0;
                        int tempIDPersona = 0;

                        while (dr2.Read())
                        {
                            tempIDPersona = Int16.Parse(dr2["IDPersona"].ToString());
                        }
                        IDPersona = tempIDPersona;
                        dr2.Close();

                        //Inserimento valori nel database 
                        //Console.WriteLine("\n" + m.Targa + "\n" + IDVeicolo + "\n" + IDPersona + "\n" + m.OraIngresso + "\n" + m.PrezzoTotale + "\n" + m.point.X + "\n" + m.point.Y);
                        comando.CommandText = "UPDATE tblParcheggioCorrente SET IDVeicolo = @IDVeicolo, DataIngresso = @DataIngresso, PrezzoIniziale = @PrezzoIniziale WHERE PosX = @x AND PosY = @y";
                        comando.Parameters.AddWithValue("@IDVeicolo", IDVeicolo);
                        comando.Parameters.AddWithValue("@DataIngresso", m.OraIngresso);
                        comando.Parameters.AddWithValue("@PrezzoIniziale", m.PrezzoTotale);
                        comando.Parameters.AddWithValue("@x", m.point.X);
                        comando.Parameters.AddWithValue("@y", m.point.Y);
                        comando.ExecuteNonQuery();


                    }
                }
                return tempPos;


            }
            else
            {
                MessageBox.Show("La targa inserita è già presente", "Attenzione", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return null;
            }

        }

        public double? Esci(Button btnTmp, List<string> posizione)
        {

            DateTime oraUscita = new DateTime();
            oraUscita = DateTime.Now;

            string convert = Regex.Match(btnTmp.Name, @"\d+").Value;
            int x = 0;
            int y = 0;
            int cont = 0;
            string[] words = posizione[Int32.Parse(convert) - 1].Split(',');
            foreach (string s in words)
            {
                if (cont == 0)
                    x = Int32.Parse(s);
                else
                    y = Int32.Parse(s);
                cont++;
            }

            double differenzaSecondi = 0;
            bool controlReturn = false;
            TimeSpan tempDifferenzaSecondi;
            foreach (Auto a in Macchine)
            {
                if (a.point.X == x && a.point.Y == y)
                {
                    var differenzaDate = oraUscita.Hour - a.OraIngresso.Hour;
                    if (differenzaDate <= 0)
                        differenzaDate = 1;


                    a.PrezzoTotale += differenzaDate * TariffaOraria[a.TipoVeicolo];
                    statoParcheggio.Add(a.Targa, false);
                    int tempStampaRiga = a.point.X + 1;
                    int tempStampaCol = a.point.Y + 1;
                    tempDifferenzaSecondi = oraUscita.Subtract(a.OraIngresso);
                    btnTmp.Image = null;
                    Macchine.Remove(a);
                    btnTmp.BackColor = Color.Green;
                    btnTmp.Text = "";
                    Image mg = Image.FromFile(@"C:\Users\Local\Desktop\GenericsParcheggioPack\freePark.PNG");
                    btnTmp.Image = mg;
                    btnTmp.ImageAlign = ContentAlignment.TopLeft;
                    differenzaSecondi = (oraUscita - a.OraIngresso).TotalSeconds;
                    string message = a.Intestatario.Cognome + " " + a.Intestatario.Nome + "\nHai parcchggiato qui " + a.Targa + " in data " + a.OraIngresso + " e ritirato l'auto in data " + oraUscita + "\nPosizione: " + tempStampaRiga + "," + tempStampaCol + " \nTempo trascorso: " + tempDifferenzaSecondi + "\nPrezzo totale: " + a.PrezzoTotale + "€";
                    MessageBox.Show(message, "Park", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    controlReturn = true;
                    string connstring = "Server=DESKTOP-C85IVGL\\SQLEXPRESSNEW;Database=ParcheggioDB;User Id=sa;Password=Ciao*2002";
                    using (SqlConnection connection = new SqlConnection(connstring))
                    {
                        connection.Open();
                        string sqlCommand = "UPDATE tblParcheggioCorrente SET IDVeicolo = NULL, DataIngresso = NULL, PrezzoIniziale = NULL WHERE PosX = @x AND PosY = @y";
                        using (SqlCommand comando = new SqlCommand(sqlCommand, connection))
                        {
                            comando.Parameters.AddWithValue("@x", x);
                            comando.Parameters.AddWithValue("@y", y);
                            comando.ExecuteNonQuery();

                            comando.CommandText = "INSERT INTO tblParcheggioStorico (Targa, Tipo, Nome, Cognome, DataIngresso, DataUscita, PrezzoFinale, PosX, PosY) VALUES (@Targa, @Tipo, @Nome, @Cognome, @DataIngresso, @DataUscita, @PrezzoFinale, @PosX, @PosY)";
                            comando.Parameters.AddWithValue("@Targa", a.Targa);
                            comando.Parameters.AddWithValue("@Tipo", a.TipoVeicolo);
                            comando.Parameters.AddWithValue("@Nome", a.Intestatario.Nome);
                            comando.Parameters.AddWithValue("@Cognome", a.Intestatario.Cognome);
                            comando.Parameters.AddWithValue("@DataIngresso", a.OraIngresso);
                            comando.Parameters.AddWithValue("@DataUscita", oraUscita);
                            comando.Parameters.AddWithValue("@PrezzoFinale", a.PrezzoTotale);
                            comando.Parameters.AddWithValue("@PosX", a.point.X);
                            comando.Parameters.AddWithValue("@PosY", a.point.Y);
                            comando.ExecuteNonQuery();
                        }
                    }
                    break;
                }
            }
            if (controlReturn)
                return differenzaSecondi;
            else
                return null;
        }

        public void EntraSetUp(string tbTarga, string tipoVeicolo, int x, int y, DateTime oraIngresso, string nome, string cognome, List<string> ServizioAggiuntivo, Button btnTmp)
        {
            double tempServizi = 0;
            for (int i = 0; i < ServizioAggiuntivo.Count; i++)
                for (int j = 0; j < TariffaServizi.Count; j++)
                    if (ServizioAggiuntivo[i] == TariffaServizi.ElementAt(j).Key)
                        tempServizi += TariffaServizi[ServizioAggiuntivo[i]];
            Auto m = new Auto(tbTarga, oraIngresso, x, y, tempServizi, tipoVeicolo, ServizioAggiuntivo, nome, cognome);
            Macchine.Add(m);
            Image mg = Image.FromFile(@"C:\Users\Local\Desktop\GenericsParcheggioPack\car.PNG");
            btnTmp.ImageAlign = ContentAlignment.MiddleCenter;
            btnTmp.Image = mg;
            int tempStampaRiga = m.point.X + 1;
            int tempStampaCol = m.point.Y + 1;
            string message = m.Intestatario.Cognome + " " + m.Intestatario.Nome + "\nHai parcheggiato qui la macchina " + m.Targa + " in data: " + m.OraIngresso + "\nPosizione: " + tempStampaRiga + "," + tempStampaCol;
            statoParcheggio.Add(m.Targa, true);
            btnTmp.BackColor = Color.Red;
            btnTmp.Text = m.Targa;
            btnTmp.TextAlign = ContentAlignment.TopLeft;
            int[] tempPos = new int[2];
            tempPos[0] = m.point.X;
            tempPos[1] = m.point.Y;
            Console.WriteLine("CIAO");
        }
    }
}

