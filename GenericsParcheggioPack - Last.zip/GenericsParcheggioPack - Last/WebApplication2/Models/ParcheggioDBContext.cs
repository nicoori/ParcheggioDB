﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace WebApplication2.Models
{
    public partial class ParcheggioDBContext : DbContext
    {
        public ParcheggioDBContext()
        {
        }

        public ParcheggioDBContext(DbContextOptions<ParcheggioDBContext> options)
            : base(options)
        {
        }

        public virtual DbSet<DboTblParcheggioCorrente> DboTblParcheggioCorrentes { get; set; } = null!;
        public virtual DbSet<DboTblParcheggioStorico> DboTblParcheggioStoricos { get; set; } = null!;
        public virtual DbSet<DboTblPersona> DboTblPersonas { get; set; } = null!;
        public virtual DbSet<TblUser> TblUsers { get; set; } = null!;
        public virtual DbSet<Tblveicolo> Tblveicolos { get; set; } = null!;

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
                optionsBuilder.UseSqlServer("Server=DESKTOP-5UU0133\\SQLEXPRESS;Database=ParcheggioDB;Trusted_Connection=True;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<DboTblParcheggioCorrente>(entity =>
            {
                entity.HasKey(e => e.Idparcheggio);

                entity.ToTable("dbo.tblParcheggioCorrente");

                entity.Property(e => e.Idparcheggio)
                    .ValueGeneratedNever()
                    .HasColumnName("IDParcheggio");

                entity.Property(e => e.DataIngresso).HasColumnType("datetime");

                entity.Property(e => e.Idveicolo).HasColumnName("IDVeicolo");
            });

            modelBuilder.Entity<DboTblParcheggioStorico>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("dbo.tblParcheggioStorico");

                entity.Property(e => e.Cognome)
                    .HasMaxLength(100)
                    .IsFixedLength();

                entity.Property(e => e.DataIngresso).HasColumnType("datetime");

                entity.Property(e => e.DataUscita).HasColumnType("datetime");

                entity.Property(e => e.Idstorico).HasColumnName("IDStorico");

                entity.Property(e => e.Nome)
                    .HasMaxLength(100)
                    .IsFixedLength();

                entity.Property(e => e.Targa)
                    .HasMaxLength(10)
                    .IsFixedLength();

                entity.Property(e => e.Tipo)
                    .HasMaxLength(50)
                    .IsFixedLength();
            });

            modelBuilder.Entity<DboTblPersona>(entity =>
            {
                entity.HasKey(e => e.Idpersona);

                entity.ToTable("dbo.tblPersona");

                entity.Property(e => e.Idpersona)
                    .ValueGeneratedNever()
                    .HasColumnName("IDPersona");

                entity.Property(e => e.Cognome)
                    .HasMaxLength(100)
                    .IsFixedLength();

                entity.Property(e => e.Nome)
                    .HasMaxLength(100)
                    .IsFixedLength();

                entity.HasOne(d => d.IdpersonaNavigation)
                    .WithOne(p => p.DboTblPersona)
                    .HasForeignKey<DboTblPersona>(d => d.Idpersona)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_dbo.tblPersona_tblveicolo");
            });

            modelBuilder.Entity<TblUser>(entity =>
            {
                entity.HasKey(e => e.Iduser)
                    .HasName("PK_Table_1");

                entity.ToTable("tblUser");

                entity.Property(e => e.Iduser)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Password)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.UserName)
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Tblveicolo>(entity =>
            {
                entity.HasKey(e => e.Idveicolo);

                entity.ToTable("tblveicolo");

                entity.Property(e => e.Idveicolo)
                    .ValueGeneratedNever()
                    .HasColumnName("IDVeicolo");

                entity.Property(e => e.Coperto)
                    .HasMaxLength(10)
                    .IsFixedLength();

                entity.Property(e => e.Idpersona).HasColumnName("IDPersona");

                entity.Property(e => e.Parcheggiatore)
                    .HasMaxLength(10)
                    .IsFixedLength();

                entity.Property(e => e.PuliziaEsterna)
                    .HasMaxLength(10)
                    .IsFixedLength();

                entity.Property(e => e.PuliziaInterna)
                    .HasMaxLength(10)
                    .IsFixedLength();

                entity.Property(e => e.Targa)
                    .HasMaxLength(10)
                    .IsFixedLength();

                entity.Property(e => e.Tipo)
                    .HasMaxLength(10)
                    .IsFixedLength();

                entity.HasOne(d => d.IdveicoloNavigation)
                    .WithOne(p => p.Tblveicolo)
                    .HasForeignKey<Tblveicolo>(d => d.Idveicolo)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_tblveicolo_dbo.tblParcheggioCorrente");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
