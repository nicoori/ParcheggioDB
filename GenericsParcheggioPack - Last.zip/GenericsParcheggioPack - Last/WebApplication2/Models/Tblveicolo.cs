﻿using System;
using System.Collections.Generic;

namespace WebApplication2.Models
{
    public partial class Tblveicolo
    {
        public long Idveicolo { get; set; }
        public long? Idpersona { get; set; }
        public string? Targa { get; set; }
        public string? Tipo { get; set; }
        public string? Coperto { get; set; }
        public string? PuliziaInterna { get; set; }
        public string? PuliziaEsterna { get; set; }
        public string? Parcheggiatore { get; set; }

        public virtual DboTblParcheggioCorrente IdveicoloNavigation { get; set; } = null!;
        public virtual DboTblPersona DboTblPersona { get; set; } = null!;
    }
}
