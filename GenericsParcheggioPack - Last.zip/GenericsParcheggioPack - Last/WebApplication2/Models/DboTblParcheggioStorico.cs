﻿using System;
using System.Collections.Generic;

namespace WebApplication2.Models
{
    public partial class DboTblParcheggioStorico
    {
        public long Idstorico { get; set; }
        public string Targa { get; set; } = null!;
        public string Tipo { get; set; } = null!;
        public string Nome { get; set; } = null!;
        public string Cognome { get; set; } = null!;
        public DateTime DataIngresso { get; set; }
        public DateTime DataUscita { get; set; }
        public double PrezzoFinale { get; set; }
        public short PosX { get; set; }
        public short PosY { get; set; }
    }
}
