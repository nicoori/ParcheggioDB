﻿using System;
using System.Collections.Generic;

namespace WebApplication2.Models
{
    public partial class DboTblParcheggioCorrente
    {
        public long Idparcheggio { get; set; }
        public long Idveicolo { get; set; }
        public DateTime DataIngresso { get; set; }
        public double PrezzoIniziale { get; set; }
        public short PosX { get; set; }
        public short PosY { get; set; }

        public virtual Tblveicolo Tblveicolo { get; set; } = null!;
    }
}
