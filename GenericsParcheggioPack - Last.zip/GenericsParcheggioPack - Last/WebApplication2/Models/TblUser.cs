﻿using System;
using System.Collections.Generic;

namespace WebApplication2.Models
{
    public partial class TblUser
    {
        public string Iduser { get; set; } = null!;
        public string? UserName { get; set; }
        public string? Password { get; set; }
    }
}
