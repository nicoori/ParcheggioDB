﻿using System;
using System.Collections.Generic;

namespace WebApplication2.Models
{
    public partial class DboTblPersona
    {
        public long Idpersona { get; set; }
        public string Nome { get; set; } = null!;
        public string Cognome { get; set; } = null!;

        public virtual Tblveicolo IdpersonaNavigation { get; set; } = null!;
    }
}
