﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using WebApplication2.Models;

namespace WebApplication2.Controllers
{
    [Route("api/v1/parcheggio")]
    [ApiController]
    [Authorize]
    public class ParcheggioController : ControllerBase
    {
        [HttpGet("/corrente")]
        public ActionResult getAll()
        {
            try
            {
                using (ParcheggioDBContext model = new ParcheggioDBContext())
                {
                    TblUser candidate = getSessionUser(model);
                    if (candidate == null) return NotFound();

                    var retVal = model.DboTblParcheggioCorrentes.Select(s => new { Idparcheggio = s.Idparcheggio, Idveicolo = s.Idveicolo,
                        DataIngresso = s.DataIngresso, PrezzoIniziale = s.PrezzoIniziale, PosX = s.PosX, PosY = s.PosY })
                        .OrderBy(ob => ob.Idparcheggio).ToList();
                    
                    return StandartResult(retVal);
                }
            }
            catch (Exception)
            {
                return Problem();
            }
        }

        [HttpGet("/storico")]
        public ActionResult getStorico()
        {
            try
            {
                using (ParcheggioDBContext model = new ParcheggioDBContext())
                {
                    TblUser candidate = getSessionUser(model);
                    if (candidate == null) return NotFound();

                    var retVal = model.DboTblParcheggioStoricos.Select(s => new { Idstorico = s.Idstorico, Targa = s.Targa
                        , Tipo = s.Tipo, Nome = s.Nome, Cognome = s.Cognome, DataIngresso = s.DataIngresso, DataUscita = s.DataUscita,
                        PrezzoFinale = s.PrezzoFinale, PosX = s.PosX, PosY = s.PosY }).OrderBy(ob => ob.Idstorico).ToList();

                    return StandartResult(retVal);
                }
            }
            catch (Exception)
            {
                return Problem();
            }
        }

        private TblUser getSessionUser(ParcheggioDBContext model)
        {
            int idUtente = Int32.Parse(HttpContext.User.Claims.FirstOrDefault(x => x.Type == "id").Value);
            return model.TblUsers.FirstOrDefault(q => q.Iduser == idUtente);
        }

        private ActionResult StandartResult(object retVal)
        {
            if (retVal == null) return NotFound();
            return Ok(retVal);
        }
    }
}
