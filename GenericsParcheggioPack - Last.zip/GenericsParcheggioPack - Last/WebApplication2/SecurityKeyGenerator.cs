﻿using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebApplication2.Models;
using Microsoft.AspNetCore.Hosting;

namespace WebApplication2
{
    public class SecurityKeyGenerator
    {
        public static SecurityKey GetSecurityKey(TblUser tblUser)
{
            var key = Encoding.ASCII.GetBytes(Startup.MasterKey + tblUser.ToString());
            return new SymmetricSecurityKey(key);
        }

        public static SecurityKey GetSecurityKey(int userId)
        {
            using (ParcheggioDBContext model = new ParcheggioDBContext())
            {
                TblUser tblUser = model.TblUsers.FirstOrDefault(q => q.Iduser == userId);
                return GetSecurityKey(tblUser);
            }
        }
    }
}