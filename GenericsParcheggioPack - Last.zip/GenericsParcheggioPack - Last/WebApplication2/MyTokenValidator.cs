﻿using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace WebApplication2
{
    public class MyTokenValidator : JwtSecurityTokenHandler, ISecurityTokenValidator
    {
        public override ClaimsPrincipal ValidateToken(string token, TokenValidationParameters validationParameters, out SecurityToken validatedToken)
        {
            try
            {
                JwtSecurityToken incomingToken = ReadJwtToken(token);

                int userId = Int32.Parse(incomingToken.Claims.FirstOrDefault(q => q.Type == "id").Value);
                validationParameters.IssuerSigningKey = SecurityKeyGenerator.GetSecurityKey(userId);

                return base.ValidateToken(token, validationParameters, out validatedToken);
            }
            catch (Exception e)
            {
                validatedToken = null;
                return new ClaimsPrincipal();
            }
        }
    }
}